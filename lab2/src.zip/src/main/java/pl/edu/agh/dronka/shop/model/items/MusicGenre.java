package pl.edu.agh.dronka.shop.model.items;

public enum MusicGenre {
    CLASSICAL,
    BLUES,
    COUNTRY,
    HIP_HOP,
    JAZZ,
    POP,
    ROCK,
    METAL,
    PUNK;
}
