package pl.agh.edu.dp.labirynth;

public class PlayerBombedException extends RuntimeException{
}
