package pl.agh.edu.dp.labirynth.enterable;

public class BombedWall extends Wall{
    @Override
    public String toString() {
        return "bombed wall";
    }
}
