package pl.agh.edu.dp.labirynth.enterable;

public class EnchantedWall extends Wall{
    @Override
    public String toString() {
        return "enchanted wall";
    }
}
